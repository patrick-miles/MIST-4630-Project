package model;

public class Person {
	private int id;
	private String firstName;
	private String lastName;
	private String DOB;
	private String gender;
	private String address;
	private String email;
	private String phoneNumber;
	private String deptPosition;
	private String radioNum;
	private String stationNum;
	private boolean isActive;
	
	
	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param dOB
	 * @param gender
	 * @param address
	 * @param email
	 * @param phoneNumber
	 * @param deptPosition
	 * @param radioNum
	 * @param stationNum
	 * @param isActive
	 */
	public Person(){
		
	}
	
	public Person(int id, String firstName, String lastName, String dOB, String gender, String address, String email,
			String phoneNumber, String deptPosition, String radioNum, String stationNum, boolean isActive) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		DOB = dOB;
		this.gender = gender;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.deptPosition = deptPosition;
		this.radioNum = radioNum;
		this.stationNum = stationNum;
		this.isActive = isActive;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the dOB
	 */
	public String getDOB() {
		return DOB;
	}
	/**
	 * @param dOB the dOB to set
	 */
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the deptPosition
	 */
	public String getDeptPosition() {
		return deptPosition;
	}
	/**
	 * @param deptPosition the deptPosition to set
	 */
	public void setDeptPosition(String deptPosition) {
		this.deptPosition = deptPosition;
	}
	/**
	 * @return the radioNum
	 */
	public String getRadioNum() {
		return radioNum;
	}
	/**
	 * @param radioNum the radioNum to set
	 */
	public void setRadioNum(String radioNum) {
		this.radioNum = radioNum;
	}
	/**
	 * @return the stationNum
	 */
	public String getStationNum() {
		return stationNum;
	}
	/**
	 * @param stationNum the stationNum to set
	 */
	public void setStationNum(String stationNum) {
		this.stationNum = stationNum;
	}
	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
}
