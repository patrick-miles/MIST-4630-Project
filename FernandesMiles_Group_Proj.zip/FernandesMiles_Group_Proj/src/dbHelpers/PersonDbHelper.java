package dbHelpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Certification;
import model.Person;


/**
 * This refactor version moves the queries from their own objects
 * and organizes them as methods by model. 
 */

public class PersonDbHelper {

	private Connection connection;

	public PersonDbHelper() {
			connection = MyDbConnection.getConnection();
		}

		public void doAdd(Person person){
			String query = "INSERT INTO person (idPerson, firstName, lastName, DOB, Gender, Address, Email, PhoneNumber, deptPosition, radioNum, stationNum, isActive) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			try {
				PreparedStatement ps = connection.prepareStatement(query);

				ps.setInt(1, person.getId());
				ps.setString(2, person.getFirstName());
				ps.setString(3, person.getLastName());
				ps.setString(4, person.getDOB());
				ps.setString(5, person.getGender());
				ps.setString(6, person.getAddress());
				ps.setString(7, person.getEmail());
				ps.setString(8, person.getPhoneNumber());
				ps.setString(9, person.getDeptPosition());
				ps.setString(10, person.getRadioNum());
				ps.setString(11, person.getStationNum());
				ps.setBoolean(12, person.isActive());
				
				ps.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block; add real error handling!
				e.printStackTrace();
			}
		}

		public void doDelete(int id) {
			String query = "DELETE FROM person WHERE idPerson = ?";

			try {
				PreparedStatement ps = connection.prepareStatement(query);

				ps.setInt(1, id);

				ps.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block; add real error handling!
				e.printStackTrace();
			}
		}

		public void doUpdate(Person person){
			String query = "UPDATE person SET firstName=?, lastName=?, DOB=?, Gender=?, Address=?, Email=?, PhoneNumber=?, deptPosition=?, radioNum=?, stationNum=?, isActive=? WHERE idPerson=?";

			try {
				PreparedStatement ps = connection.prepareStatement(query);

				ps.setString(1, person.getFirstName());
				ps.setString(2, person.getLastName());
				ps.setString(3, person.getDOB());
				ps.setString(4, person.getGender());
				ps.setString(5, person.getAddress());
				ps.setString(6, person.getEmail());
				ps.setString(7, person.getPhoneNumber());
				ps.setString(8, person.getDeptPosition());
				ps.setString(9, person.getRadioNum());
				ps.setString(10, person.getStationNum());
				ps.setBoolean(11, person.isActive());
				ps.setInt(12, person.getId());

				ps.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block; add real error handling!
				e.printStackTrace();
			}
		}

		/**
		 * doReadAll() is a refactor of the ReadQuery object's doRead() method
		 * in the previous version.
		 * 
		 * In this version, doReadAll() returns a result set rather than 
		 * storing it as a field of this helper object. The {@link #getHTMLTable()}
		 * helper is modified to accept the result set instead.
		 *  
		 * @return ResultSet
		 */
		public ResultSet doReadAll(){
			// Other methods will expect specific fields from this result set.
			// This is one reason why it's always good practice to SELECT specific fields
			// rather than using the wild card, SELECT *

			// String query = "SELECT * FROM books"; // <-- Not as good
			String query = "SELECT idPerson, firstName, lastName, DOB, Gender, Address, Email, PhoneNumber, deptPosition, radioNum, stationNum, isActive FROM person"; // <-- Better

			ResultSet results = null;
			try {
				PreparedStatement ps = this.connection.prepareStatement(query);
				results = ps.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block; add real error handling!
				e.printStackTrace();
			}

			return results;
		}

		/**
		 * This version was refactored to accept a result set, rather than rely
		 * on a result set existing as a field of the instance.
		 * 
		 * This object could be further refactored to run without a result set. 
		 * One path  might be to create an overloaded version that takes no parameters.
		 * 
		 * @param results
		 * @return String
		 */
		public String getHTMLTable(ResultSet results){
			
			String table ="";
			table += "<table border=1 align=center>\n";
			
			table +="<tr>";
			table +="<th>";
			table += "PersonID";
			table +="</th>";
			table +="<th>";
			table += "First Name";
			table +="</th>";
			table +="<th>";
			table += "Last Name";
			table +="</th>";
			table +="<th>";
			table += "DOB";
			table +="</th>";
			table +="<th>";
			table += "Gender";
			table +="</th>";
			table +="<th>";
			table += "Address";
			table +="</th>";
			table +="<th>";
			table += "Email";
			table +="</th>";
			table +="<th>";
			table += "Phone Number";
			table +="</th>";
			table +="<th>";
			table += "Department Position";
			table +="</th>";
			table +="<th>";
			table += "Radio Number";
			table +="</th>";
			table +="<th>";
			table += "Station Number";
			table +="</th>";
			table +="<th>";
			table += "Active?";
			table +="</th>";
			table +="<th>";
			table += "Edit";
			table +="</th>";
			table +="</tr>";

			try {
				while(results.next()) {

					// Consider: Why are we creating Book objects with these results, rather 
					// than just printing the results of the query directly?
					// (It helps us validate our data.)

					Person person = new Person(
							results.getInt("idPerson"),
							results.getString("firstName"),
							results.getString("lastName"),
							results.getString("DOB"),
							results.getString("Gender"),
							results.getString("Address"),
							results.getString("Email"),
							results.getString("PhoneNumber"),
							results.getString("deptPosition"),
							results.getString("radioNum"),
							results.getString("stationNum"),
							results.getBoolean("isActive")
							);

					// Consider: Could this table row code be refactored to be part of Book?
					// Would that be a good idea or not?
					
					table +="<tr>";
					table +="\t<td>";
					table += person.getId();
					table +="</td>";
					table +="<td>";
					table += person.getFirstName();
					table +="</td>";
					table +="<td>";
					table += person.getLastName();
					table +="</td>";
					table +="<td>";
					table += person.getDOB();
					table +="</td>";
					table +="<td>";
					table += person.getGender();
					table +="</td>";
					table +="<td>";
					table += person.getAddress();
					table +="</td>";
					table +="<td>";
					table += person.getEmail();
					table +="</td>";
					table +="<td>";
					table += person.getPhoneNumber();
					table +="</td>";
					table +="<td>";
					table += person.getDeptPosition();
					table +="</td>";
					table +="<td>";
					table += person.getRadioNum();
					table +="</td>";
					table +="<td>";
					table += person.getStationNum();
					table +="</td>";
					table +="<td>";
					table += person.isActive();
					table +="</td>";
					table +="\n\t<td>";
					
					// We made changes to the Delete servlet, so that it can't be accessed via 'GET'
					// Thus, this HTML needs to change as well. 
					// We'll create a small form that POSTs instead.
					//table += "<a href=update?SKU=" + product.getSKU() + " >update</a><br>";
					
					table += "<form action=\"update\" method=\"post\">";
					table += "<input type=\"hidden\" name=\"idPerson\" value=\"" + person.getId() + "\">";
					table += "<input type=\"submit\" value=\"Update\"></form>";
					
					table += "<form action=\"delete\" method=\"post\" onsubmit= \"return confirm('Do you really want to delete the record?');\">";
					table += "<input type=\"hidden\" name=\"idPerson\" value=\"" + person.getId() + "\">";
					table += "<input type=\"submit\" value=\"Delete\"></form>";
					
					// Consider adding behavior that might make this more user friendly:
					// a) adding an "Are you sure?" Javascript popup.
					// b) adding a success message to the reloaded page.
					
					table +="</td>\n";
					
					table +="</tr>\n";

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			table += "</table>";
			return table;
		}

		/**
		 * doReadOne() is a refactor of the ReadRecord object's doRead() method
		 * in the previous version.
		 * 
		 * In this version, doReadOne() accepts an integer rather than 
		 * storing it the id as a field of this helper object. It also returns a Book
		 * object, rather than storing it as a field.
		 * 
		 * One consequence of this change is that the calling code is now responsible 
		 * for keeping track of the resulting Book reference, rather than 
		 * the helper object.
		 * 
		 * @param int
		 * @return Book
		 **/
		public Person doReadOne(int id) {
			String query = "SELECT * FROM person WHERE idPerson = ?";

			Person person = null;

			try {
				PreparedStatement ps = connection.prepareStatement(query);

				ps.setInt(1, id);
				ResultSet results = ps.executeQuery();

				results.next();

				// What if book isn't found? Is an exception thrown?
				// Is it okay to return null from this refactored method?

				person = new Person(
						results.getInt("idPerson"),
						results.getString("firstName"),
						results.getString("lastName"),
						results.getString("DOB"),
						results.getString("Gender"),
						results.getString("Address"),
						results.getString("Email"),
						results.getString("PhoneNumber"),
						results.getString("deptPosition"),
						results.getString("radioNum"),
						results.getString("stationNum"),
						results.getBoolean("isActive")
						);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return person;
		}
		
public String getCertTable(ResultSet results){
			
			String table ="";
			table += "<table border=1 align=center>\n";
			
			table +="<tr>";
			table +="<th>";
			table += "Certification ID";
			table +="</th>";
			table +="<th>";
			table += "Name";
			table +="</th>";
			table +="<th>";
			table += "Agency";
			table +="</th>";
			table +="<th>";
			table += "Duration";
			table +="</th>";
			table +="<th>";
			table += "Edit";
			table +="</th>";
			table +="</tr>";

			try {
				while(results.next()) {

					// Consider: Why are we creating Book objects with these results, rather 
					// than just printing the results of the query directly?
					// (It helps us validate our data.)

					Certification cert = new Certification(
							results.getInt("idCertification"),
							results.getString("name"),
							results.getString("agency"),
							results.getInt("duration")
							
							);

					// Consider: Could this table row code be refactored to be part of Book?
					// Would that be a good idea or not?
					
					table +="<tr>";
					table +="\t<td>";
					table += cert.getId();
					table +="</td>";
					table +="<td>";
					table += cert.getName();
					table +="</td>";
					table +="<td>";
					table += cert.getAgency();
					table +="</td>";
					table +="<td>";
					table += cert.getDuration();
					table +="</td>";
					table +="\n\t<td>";
					
					// We made changes to the Delete servlet, so that it can't be accessed via 'GET'
					// Thus, this HTML needs to change as well. 
					// We'll create a small form that POSTs instead.
					//table += "<a href=update?SKU=" + product.getSKU() + " >update</a><br>";
					
					table += "<form action=\"UpdateFormCertServlet\" method=\"post\">";
					table += "<input type=\"hidden\" name=\"idCertification\" value=\"" + cert.getId() + "\">";
					table += "<input type=\"submit\" value=\"Update\"></form>";
					
					table += "<form action=\"DeleteCertServlet\" method=\"post\" onsubmit= \"return confirm('Do you really want to delete the record?');\">";
					table += "<input type=\"hidden\" name=\"idCertification\" value=\"" + cert.getId() + "\">";
					table += "<input type=\"submit\" value=\"Delete\"></form>";
					
					// Consider adding behavior that might make this more user friendly:
					// a) adding an "Are you sure?" Javascript popup.
					// b) adding a success message to the reloaded page.
					
					table +="</td>\n";
					
					table +="</tr>\n";

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			table += "</table>";
			return table;
		}
	public ResultSet doReadAllCert(){
	// Other methods will expect specific fields from this result set.
	// This is one reason why it's always good practice to SELECT specific fields
	// rather than using the wild card, SELECT *

	// String query = "SELECT * FROM books"; // <-- Not as good
		String query = "SELECT idCertification, name, agency, duration FROM certification"; // <-- Better

		ResultSet results = null;
		try {
			PreparedStatement ps = this.connection.prepareStatement(query);
			results = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block; add real error handling!
			e.printStackTrace();
		}

		return results;
		}
	public void doAddCert(Certification cert){
		String query = "INSERT INTO certification (idCertification, name, agency, duration) values (?, ?, ?, ?)";

		try {
			PreparedStatement ps = connection.prepareStatement(query);

			ps.setInt(1, cert.getId());
			ps.setString(2, cert.getName());
			ps.setString(3, cert.getAgency());
			ps.setInt(4, cert.getDuration());
			
			
			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block; add real error handling!
			e.printStackTrace();
		}
	}
	
	public Certification doReadOneCert(int id) {
		String query = "SELECT * FROM certification WHERE idCertification = ?";

		Certification cert = null;

		try {
			PreparedStatement ps = connection.prepareStatement(query);

			ps.setInt(1, id);
			ResultSet results = ps.executeQuery();

			results.next();

			// What if book isn't found? Is an exception thrown?
			// Is it okay to return null from this refactored method?

			cert = new Certification(
					results.getInt("idCertification"),
					results.getString("name"),
					results.getString("agency"),
					results.getInt("duration")
				);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cert;
	}

	public void doUpdateCert(Certification cert){
		String query = "UPDATE certification SET name=?, agency=?, duration=? WHERE idCertification=?";

		try {
			PreparedStatement ps = connection.prepareStatement(query);

			ps.setString(1, cert.getName());
			ps.setString(2, cert.getAgency());
			ps.setInt(3, cert.getDuration());
			ps.setInt(4, cert.getId());

			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block; add real error handling!
			e.printStackTrace();
		}
	}
	
	public void doDeleteCert(int id) {
		String query = "DELETE FROM certification WHERE idCertification = ?";

		try {
			PreparedStatement ps = connection.prepareStatement(query);

			ps.setInt(1, id);

			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block; add real error handling!
			e.printStackTrace();
		}
	}
	
	public ResultSet doReadExpired(){
		// Other methods will expect specific fields from this result set.
		// This is one reason why it's always good practice to SELECT specific fields
		// rather than using the wild card, SELECT *

		// String query = "SELECT * FROM books"; // <-- Not as good
		String query = "SELECT firstName, lastName, Email, name, agency, expDate, earnedRenewed	FROM person,certification,personcertification WHERE personcertification.Person_idPerson = person.idPerson AND personcertification.Certification_idCertification = certification.idCertification AND curdate() > expDate ORDER BY person.lastName ASC"; // <-- Better

		ResultSet results = null;
		try {
			PreparedStatement ps = this.connection.prepareStatement(query);
			results = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block; add real error handling!
			e.printStackTrace();
		}

		return results;
	}

}
