package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbHelpers.PersonDbHelper;
import model.Person;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet(description = "Controller for adding a new book to the database", urlPatterns = { "/addProduct" })
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// NEVER make database changes via a GET request.
		// You don't want a web crawler accidentally modifying your data!
		throw new RuntimeException();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get the data
		// TODO: Add error checking!
	    int idPerson = Integer.parseInt(request.getParameter("idPerson"));
		String firstName = request.getParameter("firstName");
	    String lastName = request.getParameter("lastName");
	    String DOB = request.getParameter("DOB");
	    String Gender = request.getParameter("Gender");
	    String Address = request.getParameter("Address");
	    String Email = request.getParameter("Email");
	    String PhoneNumber = request.getParameter("PhoneNumber");
	    String deptPosition = request.getParameter("deptPosition");
	    String radioNum = request.getParameter("radioNum");
	    String stationNum = request.getParameter("stationNum");
	    Boolean isActive = Boolean.parseBoolean(request.getParameter("isActive"));
	    
		// set up a person object
	    Person person = new Person();
	    person.setId(idPerson);
	    person.setFirstName(firstName);
	    person.setLastName(lastName);
	    person.setDOB(DOB);
	    person.setGender(Gender);
	    person.setAddress(Address);
	    person.setEmail(Email);
	    person.setPhoneNumber(PhoneNumber);
	    person.setDeptPosition(deptPosition);
	    person.setRadioNum(radioNum);
	    person.setStationNum(stationNum);
	    person.setActive(isActive);
	    
		// set up an dbHelper object
	    PersonDbHelper pdb = new PersonDbHelper();
	    
		// pass the book to addQuery to add to the database
	    pdb.doAdd(person);
	    
		// pass execution control to the ReadServlet
	    String url = "/read";
	    
	    RequestDispatcher dispatcher = request.getRequestDispatcher(url);
	    dispatcher.forward(request, response);
	}

}
