package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbHelpers.PersonDbHelper;
import model.Certification;
import model.Person;

/**
 * Servlet implementation class AddCertServlet
 */
@WebServlet({ "/AddCertServlet", "/AddCert" })
public class AddCertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// NEVER make database changes via a GET request.
		// You don't want a web crawler accidentally modifying your data!
		throw new RuntimeException();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get the data
		// TODO: Add error checking!
	    int idCertification = Integer.parseInt(request.getParameter("idCertification"));
		String name = request.getParameter("name");
	    String agency = request.getParameter("agency");
	    int duration = Integer.parseInt(request.getParameter("duration"));
	    
	    
		// set up a person object
	    Certification cert = new Certification();
	    cert.setId(idCertification);
	    cert.setName(name);
	    cert.setAgency(agency);
	    cert.setDuration(duration);
	    	    
		// set up an dbHelper object
	    PersonDbHelper pdb = new PersonDbHelper();
	    
		// pass the book to addQuery to add to the database
	    pdb.doAddCert(cert);
	    
		// pass execution control to the ReadServlet
	    String url = "/ReadCertServlet";
	    
	    RequestDispatcher dispatcher = request.getRequestDispatcher(url);
	    dispatcher.forward(request, response);
	}


}
