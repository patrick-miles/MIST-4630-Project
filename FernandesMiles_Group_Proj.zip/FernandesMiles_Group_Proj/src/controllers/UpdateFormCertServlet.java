package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbHelpers.PersonDbHelper;
import model.Certification;
import model.Person;

/**
 * Servlet implementation class UpdateFormCertServlet
 */
@WebServlet("/UpdateFormCertServlet")
public class UpdateFormCertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateFormCertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get the bookID
		int id = Integer.parseInt(request.getParameter("idCertification"));
		
		// create dbHelper class
		PersonDbHelper pdb = new PersonDbHelper();
		
		// Use ReadRecord to get the book data
		Certification cert = pdb.doReadOneCert(id);
			
		// pass Book and control to the updateForm.jsp
		request.setAttribute("certification", cert);
		
		String url = "/updateFormCert.jsp";
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}


}
